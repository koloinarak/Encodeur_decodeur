#!/bin/bash

# Vérifier si au moins un argument est fourni
if [ "$#" -eq 0 ]; then
    echo "Usage: $0 <fichier1> [<fichier2> ...]"
    exit 1
fi


#ajout de shebang
if [ ! -f my-ball.sh ]
then 
cat << TAG_DOSSIER > my-ball.sh 
#!/bin/bash
TAG_DOSSIER
fi

# parcours des arguments
for parametre in $@; do
   
   
# Si l'élément est un fichier
if [ -f "$parametre" ]
then
# Recréer le fichier avec son contenu original
cat << TAG_DOSSIER >> my-ball.sh
 
# Recréer le fichier avec son contenu original
uudecode -o $parametre << TAG-CONTENU 
$(uuencode -m $parametre $parametre)
TAG-CONTENU

TAG_DOSSIER
       
#Si l'élement est un dossier          
elif [ -d $parametre ]
then

cat << TAG_DOSSIER >> my-ball.sh
mkdir -p $parametre

TAG_DOSSIER
for i in $(ls $parametre)
do 
$0 $parametre/$i
done
fi

done

# Changer les permissions du script my-ball.sh
chmod u+x my-ball.sh

